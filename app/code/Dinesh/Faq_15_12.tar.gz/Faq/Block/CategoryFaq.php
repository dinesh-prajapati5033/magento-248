<?php
namespace Dinesh\Faq\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\Registry;
use Magento\Catalog\Model\Category;

class CategoryFaq extends Template
{
    /**
     * @var Registry
     */
    protected $registry;

    public function __construct(
        Template\Context $context,
        Registry $registry,
        array $data = []
    ) {
        $this->registry = $registry;
        parent::__construct($context, $data);
    }

    /**
     * @return Category|null
     */
    public function getCurrentCategory()
    {
        return $this->registry->registry('current_category');
    }

    public function isEnabled(): bool
    {
        $category = $this->getCurrentCategory();
        return $category && (bool)$category->getData('faq_enabled');
    }

    public function getFaqContent(): string
    {
        $category = $this->getCurrentCategory();
        return $category ? (string)$category->getData('faq_content') : '';
    }
}
